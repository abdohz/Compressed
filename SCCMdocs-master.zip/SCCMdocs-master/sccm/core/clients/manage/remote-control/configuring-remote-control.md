---
title: "Configure remote control"
titleSuffix: "Configuration Manager"
description: "Set up remote control in System Center Configuration Manager."
ms.custom: na
ms.date: 04/23/2017
ms.prod: configuration-manager
ms.reviewer: dudeso
ms.suite: na
ms.technology:
  - configmgr-other
ms.tgt_pltfrm: na
ms.topic: article
ms.assetid: 45affc27-aa11-4249-9493-082ac23a3a3d
caps.latest.revision: 4
caps.handback.revision: 0
author: arob98
ms.author: angrobe
manager: angrobe

---
# Configuring remote control in System Center Configuration Manager

*Applies to: System Center Configuration Manager (Current Branch)*

 This procedure describes configuring the default client settings for remote control. These settings apply to all computers in your hierarchy. If you want these settings to apply to only some computers, assign a custom device client setting to a collection that contains those computers. For more information a see [How to configure client settings in System Center Configuration Manager](../../../../core/clients/deploy/configure-client-settings.md). 

To use Remote Assistance or Remote Desktop, it must be installed and configured on the computer that runs the Configuration Manager console. For more information about how to install and configure Remote Assistance or Remote Desktop, see your Windows documentation.  

#### To enable remote control and configure client settings  

1.  In the Configuration Manager console, choose **Administration** > **Client Settings** > **Default Client Settings**.  

4.  On the **Home** tab, in the **Properties** group, choose **Properties**.  

5.  In the **Default**  dialog box, choose **Remote Tools**.  

6.  Configure the remote control, Remote Assistance and Remote Desktop client settings. For a list of remote tools client settings that you can configure, see [Remote Tools](../../../../core/clients/deploy/about-client-settings.md#remote-tools).  

    You can change the company name that appears in the **ConfigMgr Remote Control** dialog box by configuring a value for **Organization name displayed in Software Center** in the **Computer Agent** client settings.  

 Client computers are configured with these settings the next time they download client policy. To initiate policy retrieval for a single client, see [How to manage clients in System Center Configuration Manager](../../../../core/clients/manage/manage-clients.md).  

#### Enable keyboard translation

By default, Configuration Manager transmits the key position from the viewer’s location to the sharer’s location. This can present a problem for keyboard configurations that differ from viewer to sharer. For example, a viewer with an English keyboard would type an “A”, but the sharer’s French keyboard would provide a “Q”. You now have the option of configuring remote control so that the character itself is transmitted from the viewer’s keyboard to the sharer, and what the viewer intends to type arrives at the sharer.

To turn on keyboard translation, in **Configuration Manager Remote Control**, choose **Action**,and choose **Enable keyboard translation** to transmit key position.

> [!NOTE]
>
> Special keys, such as ~!#@$%, will not be translated correctly.


## Keyboard shortcuts for the remote control viewer

|Keyboard shortcut|Description|  
|-----------------------|-----------------|  
|Alt+Page Up|Switches between running programs from left to right.|  
|Alt+Page Down|Switches between running programs from right to left.|  
|Alt+Insert|Cycles through running programs in the order that they were opened.|  
|Alt+Home|Displays the **Start** menu.|  
|Ctrl+Alt+End|Displays the Windows Security dialog box (Ctrl+Alt+Del).|  
|Alt+Delete|Displays the Windows menu.|  
|Ctrl+Alt+Minus Sign (on the numeric keypad)|Copies the active window of the local computer to the remote computer Clipboard.|  
|Ctrl+Alt+Plus Sign (on the numeric keypad)|Copies the entire local computer's window area to the remote computer Clipboard.|  
