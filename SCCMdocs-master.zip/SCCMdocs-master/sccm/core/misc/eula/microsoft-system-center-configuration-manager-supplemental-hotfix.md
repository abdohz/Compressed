---
title: "MICROSOFT SYSTEM CENTER CONFIGURATION MANAGER SUPPLIMENTAL HOTFIX"
ms.custom: na
ms.date: 1/20/2017
ms.prod: configuration-manager
ms.service:
ms.technology: configmgr-other
ms.reviewer: na
ms.suite: na
ms.tgt_pltfrm: na
ms.topic: article
ms.assetid: 874bec5b-e47f-4fcf-9615-87e1ae5cd75e
caps.latest.revision: 7
author: aaronczms.author: aaronczmanager: angrobe
robots: noindex,nofollow

---

# Configuration Manager Hotfix
**PLEASE NOTE:** You may use any number of copies of this update or supplemental software (“Supplement”) with your company’s validly licensed Microsoft server software or online service (“Microsoft Product”).

Refer to the Microsoft Product’s license terms for additional use terms, to identify the entity licensing this Supplement to you and for support information. You may not use the Supplement if you, or your company, do not have a license for the underlying Microsoft Product.
