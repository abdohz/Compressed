---
title: "MICROSOFT SYSTEM CENTER ENDPOINT PROTECTION SUPPLEMENTAL PLACEHOLDER EULA"
titleSuffix: "Configuration Manager"
ms.custom: na
ms.date: 10/06/2016
ms.reviewer: na
ms.suite: na
ms.tgt_pltfrm: na
ms.topic: article
ms.prod: configuration-manager
ms.service:
ms.technology:
 - configmgr-other
ms.assetid: db3ca12d-b737-40a6-8a2e-8b85c2188775
caps.latest.revision: 3
author: aaronczms.author: aaronczmanager: angrobe
robots: noindex,nofollow

---
# MICROSOFT SYSTEM CENTER ENDPOINT PROTECTION SUPPLEMENTAL PLACEHOLDER EULA*Applies to: System Center Configuration Manager (Current Branch)*
MICROSOFT SYSTEM CENTER ENDPOINT PROTECTION SUPPLEMENTAL PLACEHOLDER EULA
