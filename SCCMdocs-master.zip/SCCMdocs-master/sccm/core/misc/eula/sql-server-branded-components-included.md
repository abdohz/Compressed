---
title: "SQL Server Branded Components included with System Center Configuration Manager"
ms.custom: na
ms.date: 10/06/2016
ms.prod: configuration-manager
ms.service:
ms.technology:
 - configmgr-other
ms.reviewer: na
ms.suite: na
ms.tgt_pltfrm: na
ms.topic: article
ms.assetid: 067675e6-bfae-44d9-ac86-3bf91e4fc600
caps.latest.revision: 6
author: aaronczms.author: aaronczmanager: angrobe
robots: noindex,nofollow
---
# SQL Server Branded Components included with System Center Configuration Manager*Applies to: System Center Configuration Manager (Current Branch)*
Applies to System Center Configuration Manager (current branch – version 1511 to 1606)  

 System Center Configuration Manager contains Microsoft SQL Server branded components.The license terms that govern your use of each component can be found below. If you do not agree to the license terms for the SQL Server branded component, you may not use these programs:



-   [MICROSOFT SQL SERVER 2012 NATIVE CLIENT](http://go.microsoft.com/fwlink/?LinkID=787071)  

-   [MICROSOFT SQL SERVER 2014 EXPRESS](http://go.microsoft.com/fwlink/?LinkID=787072)  

-   [MICROSOFT SQL SERVER 2014 SHARED MANAGEMENT OBJECTS](http://go.microsoft.com/fwlink/?LinkID=787073)  

-   [MICROSOFT SQL SERVER COMPACT 4.0 SERVICE PACK 1 (SP1)](http://go.microsoft.com/fwlink/?LinkID=787074)  

-   [MICROSOFT SYSTEM CLR TYPES FOR MICROSOFT SQL SERVER 2014](http://go.microsoft.com/fwlink/?LinkID=787075)
