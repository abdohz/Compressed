---
title: "Learn about updates"
titleSuffix: "Configuration Manager"
ms.custom: na
ms.date: 10/06/2016
ms.reviewer: na
ms.suite: na
ms.tgt_pltfrm: na
ms.topic: article
ms.prod: configuration-manager
ms.service:
ms.technology:
 - configmgr-other
ms.assetid: 1fa7d0d9-4bb5-4475-82ff-0d5da4a3da61
caps.latest.revision: 4
author: aaronczms.author: aaronczmanager: angrobe
robots: noindex,nofollow

---
# Learn more about available updates for System Center Configuration Manager*Applies to: System Center Configuration Manager (Current Branch)*
If you use a release version of System Center Configuration Manager, see [What's new in System Center Configuration Manager](http://technet.microsoft.com/library/mt622084.aspx)  

 If you use a Technical Preview version of System Center Configuration Manager, see [Technical Preview for System Center Configuration Manager](http://technet.microsoft.com/library/mt595861.aspx)
