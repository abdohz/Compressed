//
//  VGPlayer.h
//  VGPlayer
//
//  Created by Vein on 2017/5/29.
//  Copyright © 2017年 Vein. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VGPlayer.
FOUNDATION_EXPORT double VGPlayerVersionNumber;

//! Project version string for VGPlayer.
FOUNDATION_EXPORT const unsigned char VGPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VGPlayer/PublicHeader.h>


