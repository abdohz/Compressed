For Developers
==============

This section contains information for developers. Read on if you're interested
in hacking beets itself or creating plugins for it.

.. toctree::

    plugins
    api
    media_file
