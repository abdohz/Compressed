Guides
======

This section contains a couple of walkthroughs that will help you get familiar
with beets. If you're new to beets, you'll want to begin with the :doc:`main`
guide.

.. toctree::
   :maxdepth: 1

   main
   tagger
   advanced
